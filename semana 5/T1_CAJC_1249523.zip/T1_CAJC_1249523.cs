﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_Cesar_Jaimes_1249523
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segunda programa");
            Console.WriteLine("ingrese su nombre");
            String sNombre = Console.ReadLine();
            Console.WriteLine("Ingrese su edad");
            string sEdad = Console.ReadLine();
            Console.WriteLine("Ingrese su Carrera");
            string sCarrera = Console.ReadLine();
            Console.WriteLine("Ingrese su Carné");
            string sCarné = Console.ReadLine();
            Console.WriteLine(" Soy " + sNombre + " Tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " mi número de carné es " + sCarné);
            Console.ReadKey();
        }
    }
}
