﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sem_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresar número positivo entero n = ");
            string n = Console.ReadLine();
            Console.WriteLine("Ingresar número positivo entero x = ");
            string x = Console.ReadLine();
            Console.WriteLine("Ingresar número positivo entero a = ");
            string a = Console.ReadLine();

            if ((double.TryParse(n, out double N)) && (double.TryParse(x, out double X))
                && (double.TryParse(a, out double A)) && N > 0 && X > 0 && A > 0)
            {

                double total1 = 0;

                for (double i = 1; i <= N; i++)
                {
                    total1 = total1 + (1 / i);
                }
                Console.WriteLine($"La suma hasta (1 / {N}) es igual a {total1}");


                double total2 = 0;

                for (double j = 1; j <= N; j++)
                {
                    total2 = total2 + (1 / Math.Pow(2, j));
                }
                Console.WriteLine($"La suma hasta (1 / 2 ^ {N}) es igual a {total2}");

                double total3 = 0;
                double k = 0;

                for (k = 0; k < N; k++)
                {
                    total3 = total3 + Math.Pow(X, k) * Math.Pow(A, N - k);
                }
                Console.WriteLine($"La suma hasta {X}^{k} * {A}^{N}-{k} es igual a {total3}");

            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.ReadKey();
        }
    }
}
