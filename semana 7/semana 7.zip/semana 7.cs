﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace semana_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Cantidad = 0; double descuento = 0;
            Console.WriteLine("Bienvenido de nuevo!");
            Console.WriteLine("Ingrese el total de su compra: ");
            Cantidad = Convert.ToDouble(Console.ReadLine());

            if (Cantidad > 0)
            {
                if (Cantidad < 400)
                {
                    descuento = 0;
                }
                else if (Cantidad <= 1000)
                {
                    descuento = Cantidad * 0.07;
                }
                else if (Cantidad <= 5000)
                {
                    descuento = Cantidad * 0.10;
                }
                else if (Cantidad <= 15000)
                {
                    descuento = Cantidad * 0.15;
                }
                else
                {
                    descuento = Cantidad * 0.25;
                }
                Console.WriteLine("El precio a pagar es de " + (Cantidad - descuento));
            }
            else
            {
                Console.WriteLine("ERROR");
                Console.WriteLine("El monto de compra no puede ser negativo");
            }
            Console.ReadKey();
        }
    }
}
